Fernhill Bakery: color files made by Palette Engine on 2026-09-28

fernhill-bakery-design-tokens.json  Token file: color.<palette>.<tone>, light roles, a color-dark group and $themes. Print and spot data sit under $extensions.com.kwadejoslin.palette.
fernhill-bakery.w3c.tokens.json  The same tokens in the W3C Design Tokens format: color values as { colorSpace, components, hex }. No $themes (the format leaves modes to its resolver module).
fernhill-bakery-colors.css  Variables on :root, dark roles under prefers-color-scheme and [data-theme="dark"], OKLCH in comments.
fernhill-bakery-color-spec.md  Per-color values, CMYK for all six print conditions with gamut flags, Pantone C/U, contrast, evidence, rationale, locks and accepted failures.
fernhill-bakery.ase  Groups: Screen RGB, Print GRACoL coated CMYK, Print uncoated CMYK, Spot approximations. SWOP and the three European conditions are not in the file; the spec text and token file carry them.
fernhill-bakery-color-spec-sheet.pdf  US Letter: a summary, one page per color, roles and role-pair checks.
fernhill-bakery.palette-project.json  Everything you have chosen, so the work is not tied to this browser. Open it again from this page.

Print swatches are lookup-table approximations, not proofs. Spot names are approximate and come from values the designer pasted.
The .ase file carries no color profile: set the CMYK working space to the profile named in each group.
